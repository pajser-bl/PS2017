package application.view;

import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;

public class OperaterMapa {
	
}
