package application.view;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.awt.Button;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.net.URL;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;

import application.Main;


public class MainViewController  {
	
	Main main;

	@FXML
	private AnchorPane content;
	
	
	@FXML
	private void goIntervencije() throws IOException{
		main.showIntervencije();
	}

	@FXML
	private void goMape() throws IOException{
		main.showMape();
	}
	
	@FXML
	private void goProfilWindow() throws IOException {
		main.showProfilWindow();
	}
	
	@FXML
	private void goHelpWindow() throws IOException {
		main.showHelpWindow();
	}
	
	@FXML
	private void goLogin() throws IOException {
		main.showLogin();
	}
	
	@FXML
	private void goNovaIntervencija() throws IOException {
		main.showNovaIntervencija();
	}
	
	@FXML
	private void goMapa() throws IOException {
		main.showMape();
	}
	
	@FXML
	private void goSesije() throws IOException {
		main.showSesije();
	}
	
	@FXML
	private void goVozila() throws IOException {
		main.showVozila();
	}

}








	/*@FXML 
	private void goHome() throws IOException {
		main.showMainItems();
	}*/

	/*@FXML
	private void loadSecond(ActionEvent event) throws IOException {
		AnchorPane pane = FXMLLoader.load(getClass().getResource("view/Intervencije.fxml"));
		rootPane.getChildren().setAll(pane);
	}

	@Override
	public void initialize(URL url, ResourceBundle rb) {
		// TODO Auto-generated method stub
		
	}

	/*@FXML 
	private void dodajDugme() throws IOException {
		main.showDodajStage();
	}*/


