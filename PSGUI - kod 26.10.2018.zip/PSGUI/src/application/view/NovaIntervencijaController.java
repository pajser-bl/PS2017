package application.view;

public class NovaIntervencijaController {

}
