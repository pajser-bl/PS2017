package application.view;

public class ProfilWindowController {

}
