package application.view;
	import javafx.scene.control.TextField;
	import javafx.scene.layout.AnchorPane;
	import javafx.scene.layout.Pane;
	import javafx.stage.Stage;

	import java.awt.Button;
	import java.awt.event.ActionEvent;
	import java.io.IOException;
	import java.net.URL;
	import java.sql.Date;
	import java.text.DateFormat;
	import java.text.SimpleDateFormat;
	import java.util.ResourceBundle;

	import javafx.fxml.FXML;
	import javafx.fxml.FXMLLoader;
import application.Login;
import application.Main;

public class LoginController {

	Login login;
		
		/*@FXML
		private void goLogin() throws IOException {
			main.showLogin();
		}*/

	}
