package application;
	
import java.awt.event.ActionEvent;
import java.io.FileInputStream;
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import application.Main;
import javafx.scene.Scene;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;

import javafx.scene.control.TextField;
public class Main extends Application {
	
	private static Stage primaryStage;
	private static BorderPane mainLayout;

	@Override
	public void start(Stage primaryStage) throws IOException {
		this.primaryStage = primaryStage;
		this.primaryStage.setTitle("Road Runner");
		
		try {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root);//-----!------
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		//maksimizranje primarnog prozora
		Screen screen = Screen.getPrimary();
		Rectangle2D bound = screen.getVisualBounds();
		primaryStage.setX(bound.getMinX());
		primaryStage.setY(bound.getMinY());
		primaryStage.setWidth(bound.getWidth());
		primaryStage.setHeight(bound.getHeight());
		primaryStage.setMaximized(false);
		showMainView();
		
		Main.primaryStage.setResizable(false);
		
	
	}
	
	//prikazivanje glavnih pogleda
	
	public void showMainView() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/MainView.fxml"));
		mainLayout = loader.load();
		Scene scene = new Scene(mainLayout);/*--*/
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	
	
	public static void showIntervencije() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/AdminIntervencije.fxml"));
		BorderPane intervencije = loader.load();
		mainLayout.setCenter(intervencije);
	}
	
	public static void showMape() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/AdminMapa.fxml"));
		BorderPane mape = loader.load();
		mainLayout.setCenter(mape);
	}
	
	public static void showProfilWindow() throws IOException {
		FXMLLoader loader = new FXMLLoader() ;
		loader.setLocation(Main.class.getResource("view/ProfilWindow.fxml"));
		BorderPane pw = loader.load();
		
		Stage addDialogStage = new Stage() ;
		addDialogStage.setTitle("Pregledaj profil");
		addDialogStage.initModality(Modality.WINDOW_MODAL); //WINDOW_MODAL - zabranjujemo pristup drugim prozorima dok smo u aktivnom prozoru
		addDialogStage.initOwner(primaryStage);
		Scene scene = new Scene(pw);
		addDialogStage.setScene(scene);
		addDialogStage.showAndWait();
		}
		
	public static void showHelpWindow() throws IOException {
		FXMLLoader loader = new FXMLLoader() ;
		loader.setLocation(Main.class.getResource("view/HelpWindow.fxml"));
		BorderPane help = loader.load();
		
		Stage addDialogStage = new Stage() ;
		addDialogStage.setTitle("Pitanja i odgovori");
		addDialogStage.initModality(Modality.WINDOW_MODAL); //WINDOW_MODAL - zabranjujemo pristup drugim prozorima dok smo u aktivnom prozoru
		addDialogStage.initOwner(primaryStage);
		Scene scene = new Scene(help);
		addDialogStage.setScene(scene);
		addDialogStage.showAndWait();
		}

	
	public static void showLogin() throws IOException {
		FXMLLoader loader = new FXMLLoader() ;
		loader.setLocation(Main.class.getResource("view/Login.fxml"));
		BorderPane help = loader.load();
		
		Stage addDialogStage = new Stage() ;
		addDialogStage.setTitle("Pitanja i odgovori");
		addDialogStage.initModality(Modality.WINDOW_MODAL); //WINDOW_MODAL - zabranjujemo pristup drugim prozorima dok smo u aktivnom prozoru
		addDialogStage.initOwner(primaryStage);
		Scene scene = new Scene(help);
		addDialogStage.setScene(scene);
		addDialogStage.showAndWait();
		}

	/*public static void showMainItems() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/MainItems.fxml"));
		BorderPane mainItems = loader.load();
		mainLayout.setCenter(mainItems);
	}
		
	public static void showAzurirajBazuScene() throws IOException {
		FXMLLoader loader = new FXMLLoader () ;
		loader.setLocation(Main.class.getResource("view/AzurirajBazu.fxml"));
		BorderPane azurirajB = loader.load();
		mainLayout.setCenter(azurirajB);
	}
	
	public static void showDodajNovuZvijezduScene() throws IOException {
		FXMLLoader loader = new FXMLLoader() ;
		loader.setLocation(Main.class.getResource("view/DodajZvijezdu.fxml"));
		BorderPane dodajZ = loader.load();
		
		Stage addDialogStage = new Stage() ;
		addDialogStage.setTitle("Dodaj Novu Zvijezdu");
		addDialogStage.initModality(Modality.WINDOW_MODAL); //WINDOW_MODAL - zabranjujemo pristup drugim prozorima dok smo u aktivnom prozoru
		addDialogStage.initOwner(primaryStage);
		Scene scene = new Scene(dodajZ);
		addDialogStage.setScene(scene);
		addDialogStage.showAndWait();
		}
	

	public static void showDodajNovuPlanetuScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/DodajPlanetu.fxml"));
		BorderPane dodajP = loader.load();
		
		Stage addDialogStage = new Stage() ;
		addDialogStage.setTitle("Dodaj Novu Planetu");
		addDialogStage.initModality(Modality.WINDOW_MODAL); //WINDOW_MODAL - zabranjujemo pristup drugim prozorima dok smo u aktivnom prozoru
		addDialogStage.initOwner(primaryStage);
		Scene scene = new Scene(dodajP);
		addDialogStage.setScene(scene);
		addDialogStage.showAndWait();	
	}

	public static void showDodajNovuCrnuRupuScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/DodajCrnuRupu.fxml"));
		BorderPane dodajCR = loader.load();
		
		Stage addDialogStage = new Stage() ;
		addDialogStage.setTitle("Dodaj Crnu Rupu");
		addDialogStage.initModality(Modality.WINDOW_MODAL); //WINDOW_MODAL - zabranjujemo pristup drugim prozorima dok smo u aktivnom prozoru
		addDialogStage.initOwner(primaryStage);
		Scene scene = new Scene(dodajCR);
		addDialogStage.setScene(scene);
		addDialogStage.showAndWait();
	}
	

	public static void showDodajNoviPrirodniSatelitScene() throws IOException {
		FXMLLoader loader = new FXMLLoader();
		loader.setLocation(Main.class.getResource("view/DodajPrirodniSatelit.fxml"));
		BorderPane dodajCR = loader.load();
		
		Stage addDialogStage = new Stage() ;
		addDialogStage.setTitle("Dodaj prirodni satelit");
		addDialogStage.initModality(Modality.WINDOW_MODAL); //WINDOW_MODAL - zabranjujemo pristup drugim prozorima dok smo u aktivnom prozoru
		addDialogStage.initOwner(primaryStage);
		Scene scene = new Scene(dodajCR, 690,750);
		addDialogStage.setScene(scene);
		addDialogStage.showAndWait();
	
	}*/
	


	public static void main(String[] args) {
		launch(args);
	}



}
