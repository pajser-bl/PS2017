package application;
import java.awt.event.ActionEvent;
import java.io.FileInputStream;
import java.io.IOException;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Rectangle2D;
import javafx.stage.Modality;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import application.Main;
import javafx.scene.Scene;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;

import javafx.scene.control.TextField;

public class Login extends Application {
		
		private static Stage primaryStage;
		private static BorderPane mainLayout;

		@Override
		public void start(Stage primaryStage) throws IOException {
			this.primaryStage = primaryStage;
			this.primaryStage.setTitle("Road Runner - Prijava");
			
			try {
				BorderPane root = new BorderPane();
				Scene scene = new Scene(root);//-----!------
				scene.getStylesheets().add(getClass().getResource("login.css").toExternalForm());
				primaryStage.setScene(scene);
				primaryStage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
			
			//maksimizranje primarnog prozora
			Screen screen = Screen.getPrimary();
			Rectangle2D bound = screen.getVisualBounds();
			/*primaryStage.setX(400);
			primaryStage.setY(300);*/
			primaryStage.setWidth(460);
			primaryStage.setHeight(470);
			primaryStage.setMaximized(false);
			showLogin();
			
			Login.primaryStage.setResizable(false);
			
		
		}
		
		public void showLogin() throws IOException {
			FXMLLoader loader = new FXMLLoader();
			loader.setLocation(Main.class.getResource("view/Login.fxml"));
			mainLayout = loader.load();
			Scene scene = new Scene(mainLayout);/*--*/
			primaryStage.setScene(scene);
			primaryStage.show();
		}
		
		public static void showMainView() throws IOException {
			FXMLLoader loader = new FXMLLoader() ;
			loader.setLocation(Main.class.getResource("view/MainView.fxml"));
			BorderPane pw = loader.load();
			
			Stage addDialogStage = new Stage() ;
			addDialogStage.setTitle("Pregledaj profil");
			addDialogStage.initModality(Modality.WINDOW_MODAL); //WINDOW_MODAL - zabranjujemo pristup drugim prozorima dok smo u aktivnom prozoru
			addDialogStage.initOwner(primaryStage);
			Scene scene = new Scene(pw);
			addDialogStage.setScene(scene);
			addDialogStage.showAndWait();
			}
		
		public static void main(String[] args) {
			launch(args);
		}
}
